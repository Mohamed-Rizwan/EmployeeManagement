﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using System.Web.Mvc;
using EmployeeManagement.Models;

namespace EmployeeManagement.ADO_commands
{
    public class EmployeeAdo
    {
        public string cs = @"Data Source = IND-600\SQLEXPRESS ; Initial Catalog = EmployeeManagement ; Integrated Security= True";
            

        public DataTable EmployeeSearch(string search)
        {
            DataTable dt = new DataTable();
            using (SqlConnection conn = new SqlConnection(cs))
            {
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
                SqlCommand cmd = new SqlCommand("select EmpId, EmpName,Jobrole from EmployeeDetails where EmpName like '%' + @empname + '%' ", conn);
                cmd.Parameters.AddWithValue("@empname", search);
                sqlDataAdapter.SelectCommand = cmd;
                sqlDataAdapter.Fill(dt);


            }
            return (dt);    
        }


        public void Addemployee(EmployeeDetails addemployee)
        {
            using (SqlConnection conn = new SqlConnection(cs))
            {
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
                conn.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO EmployeeDetails(EmpName,EmpGender,EmpEmail,EmpPhone,Jobrole,TeamId)" + " VALUES(@Name,@Gender,@Email,@Phone,@Jobrole,@Teamid)", conn);
                cmd.Parameters.AddWithValue("@Name", addemployee.Name);
                cmd.Parameters.AddWithValue("@Gender", addemployee.gender);
                cmd.Parameters.AddWithValue("@Email", addemployee.Email);
                cmd.Parameters.AddWithValue("@Phone", addemployee.PhoneNumber);
                cmd.Parameters.AddWithValue("@Jobrole", addemployee.Jobrole);
                cmd.Parameters.AddWithValue("@Teamid", addemployee.TeamId);
                sqlDataAdapter.InsertCommand = cmd;
                sqlDataAdapter.InsertCommand.ExecuteNonQuery();
            }
            return;
        }

        public DataTable EmployeeView(int id) 
        {
            DataTable dt = new DataTable();
            using (SqlConnection conn = new SqlConnection(cs))
            {
                SqlDataAdapter adapter = new SqlDataAdapter();
                conn.Open();
                SqlCommand cmd = new SqlCommand("select EmployeeDetails.Empid, EmployeeDetails.EmpName,EmployeeDetails.EmpGender,EmployeeDetails.EmpEmail,EmployeeDetails.EmpPhone,EmployeeDetails.Jobrole, team.TeamName , team.TeamId from EmployeeDetails INNER Join team on team.TeamId = EmployeeDetails.TeamId Where EmpId=@id", conn);
                cmd.Parameters.AddWithValue("@id", id);
                adapter.SelectCommand = cmd;   
                adapter.Fill(dt);
            }
            return(dt); 

        }

        public EmployeeDetails Editemployee(DataTable datatable)
        {
            EmployeeDetails empdetails = new EmployeeDetails();
            empdetails.EmployeeId = Convert.ToInt32(datatable.Rows[0][0].ToString());
            empdetails.Name = (datatable.Rows[0][1].ToString());
            empdetails.gender = (datatable.Rows[0][2].ToString());
            empdetails.Email = (datatable.Rows[0][3].ToString());
            empdetails.PhoneNumber = (datatable.Rows[0][4].ToString());
            empdetails.Jobrole = (datatable.Rows[0][5].ToString());
            empdetails.TeamId = Convert.ToInt32(datatable.Rows[0][7].ToString());

            return(empdetails);
        }

        public void UpdateEmployee(EmployeeDetails emp)
        {
            using (SqlConnection conn = new SqlConnection(cs))
            {
                SqlDataAdapter adapter = new SqlDataAdapter();
                SqlCommand cmd = new SqlCommand("Update EmployeeDetails SET EmpName=@Name,EmpGender=@Gender,EmpEmail=@Email,EmpPhone=@Phone,Jobrole=@Jobrole,TeamId=@TeamId Where EmpId=@Id ", conn);
                cmd.Parameters.AddWithValue("@Id", emp.EmployeeId);
                cmd.Parameters.AddWithValue("@Name", emp.Name);
                cmd.Parameters.AddWithValue("@Gender", emp.gender);
                cmd.Parameters.AddWithValue("@Email", emp.Email);
                cmd.Parameters.AddWithValue("@Phone", emp.PhoneNumber);
                cmd.Parameters.AddWithValue("@Jobrole", emp.Jobrole);
                cmd.Parameters.AddWithValue("@TeamId", emp.TeamId);
                adapter.UpdateCommand = cmd;
                conn.Open();
                adapter.UpdateCommand.ExecuteNonQuery();


            }
            return;

        }
         public void  DeleteEmployee(int id)
        {
            using (SqlConnection conn = new SqlConnection(cs))
            {
                SqlDataAdapter adapter = new SqlDataAdapter();
                SqlCommand cmd = new SqlCommand("Delete From EmployeeDetails Where EmpId=@Id", conn);
                cmd.Parameters.AddWithValue("@Id", id);
                adapter.DeleteCommand = cmd;
                conn.Open();
                adapter.DeleteCommand.ExecuteNonQuery();


            }
        }
    }
   
}