﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using EmployeeManagement.Models;

namespace EmployeeManagement.ADO_commands
{
    public class TeamAdo
    {
        public string cs = @"Data Source = IND-600\SQLEXPRESS ; Initial Catalog = EmployeeManagement ; Integrated Security= True";
        public DataTable GetTeam()
        {
            DataTable dt = new DataTable();
            using (SqlConnection conn = new SqlConnection(cs))
            {
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter("select TeamId,TeamName from team", conn);

                sqlDataAdapter.Fill(dt);
               

            }
                    return (dt);
        }

        public DataTable ViewTeam()
        {
            DataTable teams = new DataTable();
            using (SqlConnection conn = new SqlConnection(cs))
            {
                SqlDataAdapter adapter = new SqlDataAdapter("select team.teamId,team.TeamName,EmployeeDetails.empName from team INNER JOIN EmployeeDetails on EmployeeDetails.empId=team.managerId", conn);
                adapter.Fill(teams);
            }
            return(teams);  
        }
      
        public void AddTeam(TeamDetails team)
        {
            using (SqlConnection conn = new SqlConnection(cs))
            {
                conn.Open();
                SqlDataAdapter adapter = new SqlDataAdapter();
                SqlCommand Command = new SqlCommand("Insert Into team(TeamName,ManagerId)" + "Values(@teamname,@managerid)", conn);
                Command.Parameters.AddWithValue("@teamname", team.TeamName);
                Command.Parameters.AddWithValue("@managerid", team.managerid);
                adapter.InsertCommand = Command;
                adapter.InsertCommand.ExecuteNonQuery();

            }
            return;
        }

        public DataTable ViewTeamMembers(int id)
        {
            DataTable teammembers = new DataTable();
            using (SqlConnection conn = new SqlConnection(cs))
            {
                SqlDataAdapter adapter = new SqlDataAdapter();
                SqlCommand cmd = new SqlCommand("Select EmpID,EmpName,jobrole from EmployeeDetails where TeamId=@id", conn);
                cmd.Parameters.AddWithValue("@id", id);
                adapter.SelectCommand = cmd;
                adapter.Fill(teammembers);
            }
            return (teammembers);
        }
    }
}