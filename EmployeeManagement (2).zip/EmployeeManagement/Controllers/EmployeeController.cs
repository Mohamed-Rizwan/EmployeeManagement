﻿using EmployeeManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.SqlClient;
using System.Data;
using EmployeeManagement.ADO_commands;

namespace EmployeeManagement.Controllers
{
    public class EmployeeController : Controller
    {
        // GET: Employee
        public ActionResult Index()
        {
            return View();
           
        }

        public ActionResult search()
        {
            DataTable dt = new DataTable(); 
            return View(dt);    
        }

        [HttpPost]
        public ActionResult search(string search)
        {
            EmployeeAdo find = new EmployeeAdo();
           
              return View(find.EmployeeSearch(search));
        }

        public ActionResult addemp()
        {
            TeamAdo team = new TeamAdo();
            EmployeeDetails employee = new EmployeeDetails();
            DataTable dataTable = team.GetTeam();
            ViewBag.TeamList = employee.ToSelectList(dataTable, "TeamId", "TeamName");
            return View();
            
            
        }

      

        [HttpPost]
        public ActionResult addemp(EmployeeDetails addemployee)
        {
            if (ModelState.IsValid == true)
            {
                EmployeeAdo employee = new EmployeeAdo();
                employee.Addemployee(addemployee);
                return RedirectToAction("search");
            }
            else
            {
                TeamAdo team = new TeamAdo();
                EmployeeDetails employee = new EmployeeDetails();
                DataTable dataTable = team.GetTeam();
                ViewBag.TeamList = employee.ToSelectList(dataTable, "TeamId", "TeamName");

                return View(addemployee);
            }

           
        }

        public ActionResult EmpView(int id)
        {
           
           EmployeeAdo view = new EmployeeAdo();    
           var datatable = view.EmployeeView(id);
            return View(datatable);
        }

        public ActionResult Edit(int id)
        {
            
            EmployeeAdo view = new EmployeeAdo();
            var datatable = view.EmployeeView(id);
            if (datatable.Rows.Count == 1)
            {
                TeamAdo teamget = new TeamAdo();
                var team = teamget.GetTeam();
                EmployeeAdo editget = new EmployeeAdo();
                var empdetails= editget.Editemployee(datatable);
                ViewBag.TeamList = empdetails.ToSelectList(team, "TeamId", "TeamName");
               
          

                return View(empdetails);

            }
            else
            {
                return null;
            }

        }

        [HttpPost]
        public ActionResult Edit(EmployeeDetails emp)
        {
            if (ModelState.IsValid == true) {
                EmployeeAdo update = new EmployeeAdo();
                update.UpdateEmployee(emp);
                return RedirectToAction("Search");
            }
            else
            {
                TeamAdo team = new TeamAdo();
                EmployeeDetails employee = new EmployeeDetails();
                DataTable dataTable = team.GetTeam();
                ViewBag.TeamList = employee.ToSelectList(dataTable, "TeamId", "TeamName");

                return View(emp);
            }
      


           
        }

        public ActionResult Delete(int id)
        {
            EmployeeAdo delete = new EmployeeAdo();
            delete.DeleteEmployee(id);
            return RedirectToAction("Search");
        }

       
      

    }
}